<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

/* --- ADD PRODUCT --- */
if (isset($_POST['add_product'])) {
    $name        = $_POST['name'];
    $price       = $_POST['price'];
    $description = $_POST['description'];
    
    // kategori sementara kosong
    $kategori = "";

    // Upload image
    $imgName  = $_FILES['image']['name'];
    $tmpName  = $_FILES['image']['tmp_name'];
    $folder   = "uploads/" . $imgName;

    if (move_uploaded_file($tmpName, $folder)) {

        $stmt = $mysqli->prepare(
            "INSERT INTO barang (nama, kategori, harga, deskripsi, gambar)
             VALUES (?, ?, ?, ?, ?)"
        );

        $stmt->bind_param("ssdss", $name, $kategori, $price, $description, $imgName);
        $stmt->execute();

        if ($stmt->error) {
            echo "Query Error: " . $stmt->error;
        }
    } 
}



/* --- GET PRODUCTS --- */
$products = $mysqli->query("SELECT * FROM barang ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Produk — Admin FreshlyMilk</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="images/logo.png">
<style>
    body {
        font-family: 'Inter', sans-serif;
        background: #f5f6fa;
    }

    /* SIDEBAR */
   .sidebar {
        width: 250px;
        height: 100vh;
        background: #ffffff;
        box-shadow: 6px 6px 15px #d2d5dd, -6px -6px 15px #ffffff;
        padding: 25px 20px;
        position: fixed;
        top: 0;
        left: 0;
        border-radius: 20px;
    }
    .sidebar .brand {
        font-weight: 700;
        font-size: 22px;
        margin-bottom: 30px;
    }
    .sidebar a {
        text-decoration: none;
        display: block;
        padding: 12px 18px;
        margin-bottom: 8px;
        border-radius: 12px;
        color: #333;
        font-weight: 500;
        transition: .2s;
    }
    .sidebar a:hover,
    .sidebar .active {
        background: #e9f0ff;
        color: #3b5bff;
    }

    /* MAIN */
    .main {
        margin-left: 280px;
        padding: 30px;
    }

    /* PRODUCT CARD */
    .product-card {
        background: white;
        border-radius: 15px;
        padding: 15px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        text-align: center;
        transition: .2s;
    }
    .product-card:hover {
        transform: translateY(-5px);
    }
    .product-card img {
        height: 130px;
        width: 100%;
        object-fit: cover;
        border-radius: 12px;
        margin-bottom: 15px;
    }
    .product-name {
        font-weight: 600;
        font-size: 17px;
    }
    .product-price {
        color: #ff6b2c;
        font-size: 18px;
        font-weight: 700;
        margin: 5px 0;
    }
    .btn-add {
        background: #ff6b2c;
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 10px;
        font-size: 15px;
    }
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="brand">FreshlyMilk Admin</div>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="produk.php" class="active">Produk</a>
    <a href="transaksi.php">Transaksi</a>

    <hr>
    <a href="logout.php" style="color:#d9534f;">Logout</a>
</div>

<!-- MAIN PAGE -->
<div class="main">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">Manajemen Produk</h3>
        <button class="btn-add" data-bs-toggle="modal" data-bs-target="#addModal">+ Tambah Produk</button>
    </div>

    <!-- PRODUCT GRID -->
    <div class="row g-4">

        <?php while ($p = $products->fetch_assoc()): ?>
        <div class="col-md-3">
            <div class="product-card">
                <img src="uploads/<?= $p['gambar'] ?>" alt="Produk">

<div class="product-name"><?= $p['nama'] ?></div>

<div class="product-price">Rp <?= number_format($p['harga']) ?></div>

<small class="text-muted"><?= $p['deskripsi'] ?></small>


                <div class="mt-3 d-flex gap-2 justify-content-center">
                     <button class="btn btn-warning btn-sm"
                        data-bs-toggle="modal"
                        data-bs-target="#editModal<?= $p['id'] ?>">Edit</button>
                    <button class="btn btn-danger btn-sm"
                        data-bs-toggle="modal"
                        data-bs-target="#deleteModal<?= $p['id'] ?>">Hapus</button>
                </div>
            </div>
        </div>
        
        <!-- EDIT MODAL -->
        <div class="modal fade" id="editModal<?= $p['id'] ?>">
            <div class="modal-dialog">
                <form action="produk_edit.php" method="POST" enctype="multipart/form-data" class="modal-content">

                    <div class="modal-header">
                        <h5>Edit Produk</h5>
                        <button class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">

                        <input type="hidden" name="id" value="<?= $p['id'] ?>">

                        <label>Nama</label>
                        <input type="text" name="name" value="<?= $p['nama'] ?>" class="form-control" required>

                        <label class="mt-3">Harga</label>
                        <input type="number" name="price" value="<?= $p['harga'] ?>" class="form-control" required>

                        <label class="mt-3">Deskripsi</label>
                        <textarea name="description" class="form-control" required><?= $p['deskripsi'] ?></textarea>

                        <label class="mt-3">Foto Baru (opsional)</label>
                        <input type="file" name="image" class="form-control">

                    </div>

                    <div class="modal-footer">
                        <button type="submit" name="update_product" class="btn btn-primary">Simpan Perubahan</button>
                    </div>

                </form>
            </div>
        </div>

        <!-- DELETE MODAL -->
        <div class="modal fade" id="deleteModal<?= $p['id'] ?>">
            <div class="modal-dialog">
                <form action="produk_delete.php" method="POST" class="modal-content">

                    <div class="modal-header">
                        <h5>Hapus Produk</h5>
                        <button class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                        <p>Yakin ingin menghapus <b><?= $p['nama'] ?></b>?</p>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" name="delete_product" class="btn btn-danger">Hapus</button>
                    </div>

                </form>
            </div>
        </div>

        <?php endwhile; ?>

    </div>
</div>

<!-- ADD PRODUCT MODAL -->
<div class="modal fade" id="addModal">
  <div class="modal-dialog">
    <form method="POST" enctype="multipart/form-data" class="modal-content">

        <div class="modal-header">
            <h5 class="modal-title">Tambah Produk</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

            <label class="form-label">Nama Produk</label>
            <input type="text" name="name" class="form-control" required>

            <label class="form-label mt-3">Harga</label>
            <input type="number" name="price" class="form-control" required>

            <label class="form-label mt-3">Deskripsi</label>
            <textarea name="description" class="form-control" required></textarea>

            <label class="form-label mt-3">Foto Produk</label>
            <input type="file" name="image" class="form-control" required>

        </div>

        <div class="modal-footer">
            <button type="submit" name="add_product" class="btn btn-primary">Simpan</button>
        </div>

    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
