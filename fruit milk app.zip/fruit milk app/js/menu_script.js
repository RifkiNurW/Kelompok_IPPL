// =============================================================
// ORDER SYSTEM
// =============================================================

let orderList = [];
let orderContainer = document.getElementById("orderList");
let totalAmountText = document.getElementById("totalAmount");

// Format rupiah
function formatRupiah(num) {
    return "Rp " + num.toLocaleString("id-ID");
}

// Update tampilan order sidebar
function renderOrder() {
    orderContainer.innerHTML = "";

    if (orderList.length === 0) {
        orderContainer.innerHTML = `<small class="text-muted">Belum ada item.</small>`;
        totalAmountText.innerText = "Rp 0";
        return;
    }

    let total = 0;

    orderList.forEach((item, index) => {
        total += item.price * item.qty;

        orderContainer.innerHTML += `
            <div class="d-flex align-items-center mb-3 border rounded p-2">
                <img src="${item.img}" width="50" class="rounded">
                <div class="ms-2 flex-grow-1">
                    <div class="fw-bold">${item.name}</div>
                    <div class="text-muted">${formatRupiah(item.price)}</div>

                    <div class="d-flex mt-2">
                        <button class="btn btn-sm btn-outline-secondary qty-btn" data-index="${index}" data-action="minus">-</button>
                        <span class="mx-2 pt-1">${item.qty}</span>
                        <button class="btn btn-sm btn-outline-secondary qty-btn" data-index="${index}" data-action="plus">+</button>
                    </div>
                </div>

                <button class="btn btn-sm btn-danger ms-2 delete-btn" data-index="${index}">x</button>
            </div>
        `;
    });

    totalAmountText.innerText = formatRupiah(total);

    attachQtyEvents();
    attachDeleteEvents();
}

// Tambah pesanan saat klik Add
document.querySelectorAll(".add-to-order").forEach(btn => {
    btn.addEventListener("click", function () {
        const id = this.dataset.id;
        const name = this.dataset.name;
        const price = parseInt(this.dataset.price);
        const img = this.dataset.img;

        // Cek apakah sudah ada di order
        const existing = orderList.find(item => item.id === id);

        if (existing) {
            existing.qty++;
        } else {
            orderList.push({
                id,
                name,
                price,
                img,
                qty: 1
            });
        }

        renderOrder();
    });
});

// Event untuk tombol + dan -
function attachQtyEvents() {
    document.querySelectorAll(".qty-btn").forEach(btn => {
        btn.addEventListener("click", function () {
            const index = this.dataset.index;
            const action = this.dataset.action;

            if (action === "plus") {
                orderList[index].qty++;
            } else if (action === "minus") {
                orderList[index].qty--;
                if (orderList[index].qty === 0) {
                    orderList.splice(index, 1);
                }
            }

            renderOrder();
        });
    });
}

// Event untuk delete item
function attachDeleteEvents() {
    document.querySelectorAll(".delete-btn").forEach(btn => {
        btn.addEventListener("click", function () {
            const index = this.dataset.index;
            orderList.splice(index, 1);
            renderOrder();
        });
    });
}

// Tombol Checkout
document.getElementById("checkoutBtn").addEventListener("click", function () {
    if (orderList.length === 0) {
        alert("Belum ada pesanan!");
        return;
    }

    // Kirim data order ke checkout.php lewat form POST
    const form = document.createElement("form");
    form.method = "POST";
    form.action = "checkout.php";

    const input = document.createElement("input");
    input.type = "hidden";
    input.name = "order_data";
    input.value = JSON.stringify(orderList);

    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
});
