<?php
require 'config.php';
session_start();

if (isset($_POST['delete_product'])) {
    $id = $_POST['id'];

    // ambil gambar lama
    $q = $mysqli->query("SELECT gambar FROM barang WHERE id=$id");
    $row = $q->fetch_assoc();

    // hapus file
    if (file_exists("uploads/" . $row['gambar'])) {
        unlink("uploads/" . $row['gambar']);
    }

    // hapus DB
    $mysqli->query("DELETE FROM barang WHERE id=$id");
}

header("Location: produk.php");
exit;
?>
