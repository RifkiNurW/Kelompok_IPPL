<?php
require 'config.php';

if (!isset($_POST['order_data'])) {
    header("Location: menu.php");
    exit;
}

$order = json_decode($_POST['order_data'], true);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Checkout</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="images/logo.png">
</head>
<body class="bg-light">

<div class="container py-5">
    <h3 class="mb-4">Checkout Pesanan</h3>

    <form action="checkout_process.php" method="POST">

        <input type="hidden" name="order_data" value='<?= json_encode($order) ?>'>

        <div class="mb-3">
            <label class="form-label">Nama Pemesan</label>
            <input type="text" name="nama" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Nomor Telepon</label>
            <input type="text" name="telepon" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Alamat</label>
            <input type="text" name="alamat" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Catatan</label>
            <textarea name="catatan" class="form-control"></textarea>
        </div>

        <!-- ========================= -->
        <!--  METODE PEMBAYARAN BARU    -->
        <!-- ========================= -->
        <h5 class="mt-4">Metode Pembayaran</h5>

        <div class="mb-3">
            <select name="pembayaran" class="form-select" required>
                <option value="" disabled selected>-- Pilih Metode Pembayaran --</option>
                <option value="Tunai">Tunai (Bayar di Tempat)</option>
                <option value="Transfer">Transfer</option>
            </select>
        </div>

        <!-- Jika pilih transfer, muncul info rekening -->
        <div id="transferInfo" class="alert alert-info d-none">
            <b>Transfer ke:</b><br>
            Bank BCA - 1234567890 (FreshlyMilk)<br>
            <br>
            <b>Transfer ke:</b><br>
            e-wallet - 1234567890 (FreshlyMilk)<br>
        </div>
        
        <h5 class="mt-4 mb-3">Ringkasan Pesanan</h5>

        <ul class="list-group mb-4">
        <?php 
        $total = 0;
        foreach ($order as $o): 
            $total += $o['price'] * $o['qty'];
        ?>
            <li class="list-group-item d-flex justify-content-between">
                <?= $o['name'] ?> (x<?= $o['qty'] ?>)
                <b>Rp <?= number_format($o['price'] * $o['qty']) ?></b>
            </li>
        <?php endforeach; ?>
            <li class="list-group-item d-flex justify-content-between bg-light">
                <b>Total</b>
                <b>Rp <?= number_format($total) ?></b>
            </li>
        </ul>

        <a href="menu.php" class="btn btn-outline-secondary w-100 mb-3">
            ⬅ Kembali ke Menu
        </a>

        <button class="btn btn-success w-100">Konfirmasi & Bayar</button>

    </form>
</div>

<script>
// Menampilkan info rekening jika pilih Transfer
document.querySelector("select[name='pembayaran']").addEventListener("change", function () {
    let info = document.getElementById("transferInfo");
    if (this.value === "Transfer") {
        info.classList.remove("d-none");
    } else {
        info.classList.add("d-none");
    }
});
</script>

</body>
</html>
