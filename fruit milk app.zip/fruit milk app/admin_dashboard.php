<?php
require 'config.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$res = $mysqli->query("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 20");
$users = $res->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Admin Dashboard — FreshlyMilk</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="images/logo.png">

<style>
    body {
        font-family: 'Inter', sans-serif;
        background: #f5f6fa;
    }

    /* SIDEBAR */
    .sidebar {
        width: 250px;
        height: 100vh;
        background: #ffffff;
        box-shadow: 6px 6px 15px #d2d5dd, -6px -6px 15px #ffffff;
        padding: 25px 20px;
        position: fixed;
        top: 0;
        left: 0;
        border-radius: 20px;
    }
    .sidebar .brand {
        font-weight: 700;
        font-size: 22px;
        margin-bottom: 30px;
    }
    .sidebar a {
        text-decoration: none;
        display: block;
        padding: 12px 18px;
        margin-bottom: 8px;
        border-radius: 12px;
        color: #333;
        font-weight: 500;
        transition: .2s;
    }
    .sidebar a:hover,
    .sidebar .active {
        background: #e9f0ff;
        color: #3b5bff;
    }

    /* MAIN CONTENT */
    .main {
        margin-left: 280px;
        padding: 30px;
    }

    /* SOFT CARD */
    .soft-card {
        background: #f5f6fa;
        border-radius: 18px;
        padding: 25px;
        box-shadow: 6px 6px 15px #d1d4db, -6px -6px 15px #ffffff;
        transition: .2s;
    }
    .soft-card:hover {
        transform: translateY(-3px);
    }
    .stat-value {
        font-size: 24px;
        font-weight: 600;
    }
    .stat-label {
        font-size: 14px;
        opacity: .7;
    }

    /* TABLE */
    .soft-table {
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 6px 6px 15px #d1d4db, -6px -6px 15px #ffffff;
    }
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="brand">FreshlyMilk Admin</div>
    <a href="admin.dashboard.php" class="active">Dashboard</a>
    <a href="produk.php">Produk</a>
    <a href="transaksi.php">Transaksi</a>

    <hr>
    <a href="logout.php" style="color: #d9534f;">Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

    <h3 class="fw-bold mb-4">Dashboard</h3>
    <!-- TABLE USER -->
    <h5 class="fw-semibold mb-3">Daftar User</h5>
    <div class="soft-table">
        <table class="table mb-0 table-hover">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Terdaftar</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= htmlspecialchars($u['username']) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td><?= htmlspecialchars($u['role']) ?></td>
                    <td><?= htmlspecialchars($u['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>
