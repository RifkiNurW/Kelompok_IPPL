<?php
require 'config.php';
session_start();

if (isset($_POST['update_product'])) {
    $id          = $_POST['id'];
    $name        = $_POST['name'];
    $price       = $_POST['price'];
    $description = $_POST['description'];

    // Jika update gambar
    if (!empty($_FILES['image']['name'])) {
        $newImg   = time() . "_" . $_FILES['image']['name'];
        $tmpName  = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmpName, "uploads/" . $newImg);

        // Update dengan gambar baru
        $stmt = $mysqli->prepare(
            "UPDATE barang SET nama=?, harga=?, deskripsi=?, gambar=? WHERE id=?"
        );
        $stmt->bind_param("sdssi", $name, $price, $description, $newImg, $id);
    } else {
        // Update tanpa gambar
        $stmt = $mysqli->prepare(
            "UPDATE barang SET nama=?, harga=?, deskripsi=? WHERE id=?"
        );
        $stmt->bind_param("sdsi", $name, $price, $description, $id);
    }

    $stmt->execute();
}

header("Location: produk.php");
exit;
?>
