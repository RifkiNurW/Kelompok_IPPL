<?php
// user_dashboard.php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
if ($_SESSION['role'] === 'admin') {
    header('Location: admin_dashboard.php');
    exit;
}

// data user
$stmt = $mysqli->prepare("SELECT username, email, created_at FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>User Dashboard - FreshlyMilk</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
  <link rel="icon" type="image/png" href="images/logo.png">


  <style>
    body {
        background-color: #f8f9fa;
    }

    /* NAVBAR */
    .navbar-custom {
        background-color: #064420;
        padding: 15px 0;
    }
    .navbar-brand {
        font-family: 'Pacifico', cursive;
        font-size: 28px;
        color: #ffe27a !important;
    }
    .navbar-nav .nav-link {
        color: white !important;
        font-weight: 500;
        margin-right: 20px;
    }
    .nav-user {
        color: #ffffffcc;
        margin-right: 15px;
    }
    .btn-logout {
        border: 1px solid #e4e4e4;
        color: white;
    }

    /* Efek hover menu navbar */
.navbar-nav .nav-link {
    color: white !important;
    font-weight: 500;
    margin-right: 20px;
    position: relative;
    transition: 0.3s;
}

/* Animasi underline */
.navbar-nav .nav-link::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: -4px;
    width: 0%;
    height: 3px;
    background: #ffffffff;
    border-radius: 5px;
    transition: width 0.3s ease-in-out;
}

/* Hover efek */
.navbar-nav .nav-link:hover {
    color: #ffe27a !important;
    transform: translateY(-2px);
}

/* Underline muncul */
.navbar-nav .nav-link:hover::after {
    width: 100%;
}


    /* HERO */
    .hero {

    height: 100vh;


        background: url('https://images.unsplash.com/photo-1543353071-10c8ba85a904') center/cover no-repeat;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        color: white;
        position: relative;
    }
    .hero-bg {
        position: absolute;
        inset: 0;
        background: rgba(0,0,0,0.45);
    }
    .hero-content {
        position: relative;
        z-index: 2;
    }
    .hero h1 {
        font-size: 50px;
        font-weight: 600;
    }
    .hero .btn-main {
        border: 2px solid white;
        padding: 10px 30px;
        font-size: 18px;
        border-radius: 8px;
        margin-top: 20px;
        color: white;
        transition: 0.3s;
    }
    .hero .btn-main:hover {
        background-color: white;
        color: #064420;
    }

    /* CARD */
    .card-dashboard {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container">
    <a class="navbar-brand" href="#">FreshlyMilk</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navmenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="user_dashboard.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
        <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
      </ul>

      <a class="btn btn-sm btn-logout" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<!-- HERO SECTION -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-content">
    <h1>Welcome to FreshlyMilk</h1>
    <a href="menu.php" class="btn-main">Book Now</a>
  </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
