<?php
// Jika butuh backend nanti bisa ditambah
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact - FreshlyMilk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="img/logo.png">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@1,400;1,600&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="images/logo.png">
    <!-- CSS -->
<style>
body {
    background: url('images/bg 2.jpeg') center/cover no-repeat fixed;
    /* Kalau mau efek gelap elegan */
    position: relative;
}

body::before {
    content: "";
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.55); /* layer gelap */
    z-index: -1;
}

    /* NAVBAR */
    .navbar-custom {
        background-color: #064420;
        padding: 15px 0;
    }
    .navbar-brand {
        font-family: 'Pacifico', cursive;
        font-size: 28px;
        color: #ffe27a !important;
    }
    .navbar-nav .nav-link {
        color: white !important;
        font-weight: 500;
        margin-right: 20px;
    }
    .nav-user {
        color: #ffffffcc;
        margin-right: 15px;
    }
    .btn-logout {
        border: 1px solid #e4e4e4;
        color: white;
    }

    /* Efek hover menu navbar */
.navbar-nav .nav-link {
    color: white !important;
    font-weight: 500;
    margin-right: 20px;
    position: relative;
    transition: 0.3s;
}

/* Animasi underline */
.navbar-nav .nav-link::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: -4px;
    width: 0%;
    height: 3px;
    background: #ffffffff;
    border-radius: 5px;
    transition: width 0.3s ease-in-out;
}

/* Hover efek */
.navbar-nav .nav-link:hover {
    color: #ffe27a !important;
    transform: translateY(-2px);
}

/* Underline muncul */
.navbar-nav .nav-link:hover::after {
    width: 100%;
}


    /* HERO */
    .hero {

    height: 100vh;


        background: url('https://images.unsplash.com/photo-1543353071-10c8ba85a904') center/cover no-repeat;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        color: white;
        position: relative;
    }
    .hero-bg {
        position: absolute;
        inset: 0;
        background: rgba(0,0,0,0.45);
    }
    .hero-content {
        position: relative;
        z-index: 2;
    }
    .hero h1 {
        font-size: 50px;
        font-weight: 600;
    }
    .hero .btn-main {
        border: 2px solid white;
        padding: 10px 30px;
        font-size: 18px;
        border-radius: 8px;
        margin-top: 20px;
        color: white;
        transition: 0.3s;
    }
    .hero .btn-main:hover {
        background-color: white;
        color: #064420;
    }

    /* CARD */
    .card-dashboard {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

/* Glass Box */
.glass-box {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(12px);
    border-radius: 18px;
    border: 1px solid rgba(255, 255, 255, 0.15);
    box-shadow: 0 0 35px rgba(255, 255, 255, 0.07);
    animation: slideUp 0.7s ease forwards;
}

@keyframes slideUp {
    from { transform: translateY(40px); opacity: 0; }
    to   { transform: translateY(0); opacity: 1; }
}

.title-elegant {
    font-family: "Playfair Display", serif;
    font-style: italic;
    font-size: 40px;
    color: white;
    margin-bottom: 40px;
}

.contact-row {
    display: flex;
    justify-content: space-between;
    padding: 15px 0;
    font-size: 17px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.4);
    color: #ffffff !important;   /* <-- TEKS JADI PUTIH */
}

.contact-row span {
    color: #ffffff !important;   /* <-- SPAN JADI PUTIH */
}

.contact-row span:first-child {
    font-weight: 600;
}

/* Info */
.contact-info h6 {
    font-size: 17px;
    margin-top: 30px;
    color: #ffd65a;
}

.contact-info p {
    margin-bottom: 10px;
    color: #ddd;
}

/* Map */
.map-frame iframe {
    width: 100%;
    height: 270px;
    border-radius: 15px;
    border: none;
}

/* Fade animation */
.fade-in {
    opacity: 0;
    animation: fade 1.2s ease forwards;
}
@keyframes fade {
    to { opacity: 1; }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container">
    <a class="navbar-brand" href="#">FreshlyMilk</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navmenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="user_dashboard.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
        <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
      </ul>

      <a class="btn btn-sm btn-logout" href="logout.php">Logout</a>
    </div>
  </div>
</nav>
<!-- END NAVBAR -->

<div class="container mt-5">
    <div class="glass-box p-5 mx-auto fade-in" style="max-width: 760px">
        <h2 class="title-elegant text-center">How to Find<br>& Contact Us</h2>

        <!-- Jam Operasional -->
        <div class="contact-row"><span>Monday - Thursday</span><span>10:00 - 22:00</span></div>
        <div class="contact-row"><span>Friday - Saturday</span><span>11:00 - 21:00</span></div>
        <div class="contact-row border-0"><span>Sunday</span><span>Closed</span></div>

        <!-- Info -->
        <div class="contact-info text-center">
            <h6>Instagram</h6>
            <p>teteroret</p>

            <h6>Business Phone:</h6>
            <p>08........</p>
        </div>

        <!-- Google Map -->
        <div class="map-frame mt-4">
<iframe
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.72169409814!2d109.24072077475546!3d-7.424551473270142!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e655ef2eec2a3c3%3A0xa6e68132c0aaf645!2sAlun-Alun%20Purwokerto!5e0!3m2!1sid!2sid!4v1732034060000!5m2!1sid!2sid"
    width="100%"
    height="270"
    style="border:0; border-radius: 15px;"
    allowfullscreen=""
    loading="lazy">
</iframe>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", () => {
    // Animasi fade muncul pelan
    const fade = document.querySelector(".fade-in");
    fade.style.opacity = "1";

    // Update cart (contoh)
    const cart = localStorage.getItem("cartCount") || 0;
    document.getElementById("cart-count").textContent = cart;
});

</script>

</body>
</html>
