<?php
// process_register.php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (strlen($username) < 3 || strlen($password) < 8) {
    header('Location: register.php?error=' . urlencode('Username minimal 3 dan password minimal 8 karakter.'));
    exit;
}

// Cek unique username/email
$stmt = $mysqli->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
$stmt->bind_param('ss', $username, $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->close();
    header('Location: register.php?error=' . urlencode('Username atau email sudah terdaftar.'));
    exit;
}
$stmt->close();

$hash = password_hash($password, PASSWORD_DEFAULT);
$ins = $mysqli->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
$ins->bind_param('sss', $username, $email, $hash);

if ($ins->execute()) {
    header('Location: login.php?success=' . urlencode('Registrasi berhasil, silakan login.'));
    exit;
} else {
    header('Location: register.php?error=' . urlencode('Terjadi kesalahan sistem.'));
    exit;
}
