<?php
// register.php
require 'config.php';
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin_dashboard.php' : 'user_dashboard.php'));
    exit;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Daftar — Fruit & Milk</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/styles.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="images/logo.png">
</head>
<body>
<div class="container py-5">
  <div class="row align-items-center">
    <div class="col-md-6">
      <div class="panel welcome-left">
        <h1>Selamat Datang!</h1>
        <p class="lead">Daftar untuk menikmati fitur manajemen akun. Tema: buah-buahan & susu murni.</p>
        <p>Jika sudah punya akun, <a href="login.php" class="text-fruit">Login di sini</a>.</p>
      </div>
    </div>

    <div class="col-md-6">
      <div class="panel">
        <h3 class="mb-3">Buat Akun</h3>
        <?php if(isset($_GET['error'])): ?>
          <div class="alert alert-danger"><?=htmlspecialchars($_GET['error'])?></div>
        <?php endif; ?>
        <form action="process_register.php" method="post">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input required name="username" class="form-control" placeholder="pilih username">
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input required type="email" name="email" class="form-control" placeholder="email@contoh.com">
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input required type="password" name="password" class="form-control" placeholder="Minimal 8 karakter">
          </div>
          <button class="btn btn-fruit w-100">Daftar Sekarang</button>
        </form>
      </div>
    </div>
  </div>
</div>
</body>
</html>
