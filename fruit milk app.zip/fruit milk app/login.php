<?php
// login.php
require 'config.php';
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin_dashboard.php' : 'user_dashboard.php'));
    exit;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login — Fruit & Milk</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/styles.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="images/logo.png">
</head>
<body>
<div class="container py-5">
  <div class="row align-items-center">
    <div class="col-md-7">
      <div class="panel">
        <h1 class="brand">Fruit & Milk</h1>
        <h2>Welcome!</h2>
        <p>Masuk untuk mengakses akun Anda. Tema: buah segar & susu murni.</p>
      </div>
    </div>
    <div class="col-md-5">
      <div class="panel">
        <h3 class="mb-3">Sign in</h3>
        <?php if(isset($_GET['error'])): ?>
          <div class="alert alert-danger"><?=htmlspecialchars($_GET['error'])?></div>
        <?php endif; ?>
        <?php if(isset($_GET['success'])): ?>
          <div class="alert alert-success"><?=htmlspecialchars($_GET['success'])?></div>
        <?php endif; ?>
        <form action="process_login.php" method="post">
          <div class="mb-3">
            <label class="form-label">Email or Username</label>
            <input required name="identifier" class="form-control" placeholder="username atau email">
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input required type="password" name="password" class="form-control" placeholder="password">
          </div>
          <button class="btn btn-fruit w-100">Submit</button>
        </form>
        <p class="mt-3">Belum punya akun? <a href="register.php" class="text-fruit">Daftar</a></p>
      </div>
    </div>
  </div>
</div>
</body>
</html>
