<?php
require 'config.php';
$id = $_GET['id'];
$trx = $mysqli->query("SELECT * FROM transaksi WHERE id=$id")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>Pesanan Berhasil</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="images/logo.png">
</head>
<body class="bg-light">

<div class="container py-5 text-center">
    <h2 class="text-success mb-3">Pesanan Berhasil!</h2>
    <p>Terima kasih, pesanan Anda sudah diterima.</p>

    <h5 class="mt-3">Total Pembayaran:</h5>
    <h3>Rp <?= number_format($trx['total']) ?></h3>

    <a href="menu.php" class="btn btn-success mt-4">Kembali ke Menu</a>
</div>

</body>
</html>
