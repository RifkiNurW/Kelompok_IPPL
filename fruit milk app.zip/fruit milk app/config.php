<?php
// config.php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';      // ganti sesuai setup Anda
$DB_PASS = '';          // ganti sesuai setup Anda
$DB_NAME = 'fruit_milk_app';

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: " . $mysqli->connect_error);
}
$mysqli->set_charset('utf8mb4');
?>
