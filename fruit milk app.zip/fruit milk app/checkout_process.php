<?php
session_start();
require 'config.php';

if (!isset($_POST['order_data'])) {
    header("Location: menu.php");
    exit;
}

$order = json_decode($_POST['order_data'], true);
$nama = $_POST['nama'];
$telepon = $_POST['telepon'];
$alamat = $_POST['alamat'];
$catatan = $_POST['catatan'];
$pembayaran = $_POST['pembayaran']; // ←

$total = 0;
foreach ($order as $o) {
    $total += $o['price'] * $o['qty'];
}

// SIMPAN KE TABEL TRANSAKSI
$stmt = $mysqli->prepare("INSERT INTO transaksi (nama, telepon, alamat, catatan, total, metode_pembayaran)
    VALUES (?, ?, ?, ?, ?, ?)
");
$stmt->bind_param("ssssis", $nama, $telepon, $alamat, $catatan, $total, $pembayaran);
$stmt->execute();

$transaksi_id = $stmt->insert_id;

// SIMPAN DETAIL TRANSAKSI
foreach ($order as $o) {
    $stmt2 = $mysqli->prepare("INSERT INTO transaksi_detail (transaksi_id, produk_id, nama_produk, harga, qty) VALUES (?,?,?,?,?)");
    $stmt2->bind_param("iisii", $transaksi_id, $o['id'], $o['name'], $o['price'], $o['qty']);
    $stmt2->execute();
}

header("Location: checkout_selesai.php?id=" . $transaksi_id);
exit;

