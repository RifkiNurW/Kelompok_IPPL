<?php
require 'config.php'; // koneksi database

// Ambil produk dari database
$products = $mysqli->query("SELECT * FROM barang ORDER BY id DESC");

// Buat daftar kategori otomatis dari database
$categories = [];
$catQuery = $mysqli->query("SELECT DISTINCT kategori FROM barang");

while($c = $catQuery->fetch_assoc()) {
    if ($c['kategori'] != "") {
        $categories[] = $c['kategori'];
    }
}

array_unshift($categories, "All"); // tambahkan kategori All
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"/>
<title>Menu</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="images/logo.png">
<style>
.sidebar-area {
    background: #494b4a99; 
    color: white;
    border-left: 3px solid #ffe58a;
    box-shadow: -5px 0 20px rgba(0,0,0,0.15);
}

.sidebar-area h6,
.sidebar-area span,
.sidebar-area b,
.sidebar-area small {
    color: #ffffff !important;
}

</style>
</head>
<body>

<div class="container-fluid page-wrap">
<div class="row gx-0">

<!-- MAIN CONTENT -->
<div class="col-12 col-lg-9 main-area p-4">

    <!-- TOMBOL KEMBALI -->
    <a href="user_dashboard.php" class="btn btn-success">
        ← Kembali
    </a>

    <div class="d-flex align-items-center mb-4">
        <h4 class="m-0">Order <span class="text-muted">something</span></h4>
    </div>


    <!-- KATEGORI -->
    <div class="categories mb-4">
        <?php foreach($categories as $cat): ?>
        <button class="cat-btn btn btn-outline-secondary btn-sm me-2 mb-2" 
                data-cat="<?=$cat?>"><?=$cat?></button>
        <?php endforeach; ?>
    </div>

    <h5 class="mb-3">Popular dishes</h5>

    <div id="menuGrid" class="row g-3">
        <?php while ($p = $products->fetch_assoc()): ?>
        <div class="col-6 col-md-4 col-xl-3 menu-card" data-category="<?=$p['kategori']?>">
            <div class="card h-100">
                <img src="uploads/<?=$p['gambar']?>" class="card-img-top">

                <div class="card-body p-3">
                    <h6><?=$p['nama']?></h6>
                    <small class="text-muted"><?=$p['deskripsi']?></small>

                    <div class="d-flex justify-content-between mt-2">
                        
                        <strong>Rp <?=number_format($p['harga'])?></strong>
                    </div>

                    <button class="btn btn-sm btn-outline-primary mt-3 add-to-order"
                        data-id="<?=$p['id']?>"
                        data-name="<?=$p['nama']?>"
                        data-price="<?=$p['harga']?>"
                        data-img="uploads/<?=$p['gambar']?>">Add</button>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

</div>

<!-- SIDEBAR ORDER -->
<div class="col-12 col-lg-3 sidebar-area p-4">
    <h6>My order</h6>
    <div id="orderList" class="order-list mb-3">
        <small class="text-muted">Belum ada item.</small>
    </div>

    <div class="d-flex justify-content-between mb-2">
        <span>Delivery 30–40 min</span>
        <b id="totalAmount">Rp 0</b>
    </div>

    <button id="checkoutBtn" class="btn btn-success w-100">Checkout</button>
</div>

</div>
</div>

<script>
<?php include 'js/menu_script.js'; // JS sama seperti sebelumnya ?>
</script>

</body>
</html>
